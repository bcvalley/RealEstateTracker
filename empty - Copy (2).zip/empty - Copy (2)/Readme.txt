Real Estate Tracker
    It allows you to add new properties as well as adding managers.
    You have an option to list all properties and it's managers as well as profits and etc.
    It stores all properties to a list that is then later saved to Props.Txt
    It does the same thing to the managers and saves them to Mans.txt.
    Then later , It reads from those txt's and takes the information in them and stores them into
    a list with the methods 